﻿using System.Collections.Generic;
using System.Linq;

namespace SMS.ProvideSMSFeatures
{

    public class BulkMessage
    {
        public string Title { get; private set; }
        public List<string> Receivers { get; private set; }
        public string Message { get; private set; }

        public BulkMessage(string title, List<string> recievers, string message)
        {
            Title = title;
            Receivers = recievers.Select(o=> (new IranMobilePhone()).RefineNumber(o)).ToList();
            Message = message;
        }
    }
}

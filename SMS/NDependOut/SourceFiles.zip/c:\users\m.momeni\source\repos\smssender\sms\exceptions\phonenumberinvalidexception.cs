﻿using System;

namespace SMS.Exceptions
{
    public class PhoneNumberInvalidException : ApplicationException
    {
        public override string Message => "Phone number is not valid.";
    }
}
